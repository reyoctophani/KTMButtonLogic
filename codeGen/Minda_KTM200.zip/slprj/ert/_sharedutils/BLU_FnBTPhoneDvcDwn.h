/*
 * File: BLU_FnBTPhoneDvcDwn.h
 *
 * Code generated for Simulink model 'ButtonLogic'.
 *
 * Model version                  : 1.470
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Thu Dec 19 13:17:00 2024
 */

#ifndef RTW_HEADER_BLU_FnBTPhoneDvcDwn_h_
#define RTW_HEADER_BLU_FnBTPhoneDvcDwn_h_

extern void BLU_FnBTPhoneDvcDwn(void);

#endif                                 /* RTW_HEADER_BLU_FnBTPhoneDvcDwn_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
