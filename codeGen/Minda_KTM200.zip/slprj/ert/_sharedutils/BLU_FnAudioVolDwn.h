/*
 * File: BLU_FnAudioVolDwn.h
 *
 * Code generated for Simulink model 'ButtonLogic'.
 *
 * Model version                  : 1.471
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Fri Dec 20 05:22:54 2024
 */

#ifndef RTW_HEADER_BLU_FnAudioVolDwn_h_
#define RTW_HEADER_BLU_FnAudioVolDwn_h_

extern void BLU_FnAudioVolDwn(void);

#endif                                 /* RTW_HEADER_BLU_FnAudioVolDwn_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
