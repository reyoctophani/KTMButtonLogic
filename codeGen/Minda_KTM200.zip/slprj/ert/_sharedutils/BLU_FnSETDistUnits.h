/*
 * File: BLU_FnSETDistUnits.h
 *
 * Code generated for Simulink model 'ButtonLogic'.
 *
 * Model version                  : 1.471
 * Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
 * C/C++ source code generated on : Fri Dec 20 05:22:54 2024
 */

#ifndef RTW_HEADER_BLU_FnSETDistUnits_h_
#define RTW_HEADER_BLU_FnSETDistUnits_h_
#include "exported_enum_type.h"

extern void BLU_FnSETDistUnits(eStateName u);

#endif                                 /* RTW_HEADER_BLU_FnSETDistUnits_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
